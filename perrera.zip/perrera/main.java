/******************************************************************
Perrera.java
Autor: Ana Paula Navas Hong
Carnet: 22731
Seccion: 20
******************************************************************/
import java.util.Scanner;

class SimuladorPerrera{
	public static void main(String[] args){
		Scanner scan = new Scanner(System.in);
		//Crear perro y persona
		int opcion = 0;
		
		while (opcion != 5){
		
			System.out.println("\n\nBienvenido al simulador de entrenamiento de voluntari@s. ¿Qué hará?");
			System.out.println("1. Nueva persona");
			System.out.println("2. Nuevo perro");
			System.out.println("3. Sacar galleta");
			System.out.println("4. Interactuar");
			System.out.println("5. Salir\n\n");
			
			opcion = scan.nextInt();
			persona persona = new persona()
			perro perro; perro = new perro();
			
			if (opcion == 1){
				System.out.println("su confiabilidad es de " + persona.getConfiabilidad());
				System.out.println("la cantidad de galletas es " + persona.tienedaGalleta());
				//Nueva persona
			} else if (opcion == 2){
				System.out.println("el animo del perro es de " + perro.getAnimo());
				System.out.println("el umbral del perro es de " + perro.getUmbral());
				//Nuevo perro
			} else if (opcion == 3){
				System.out.println(persona.tienedaGalleta());
                System.out.println("Te dare una galleta, ahora me quedan: " + persona.tienedaGalleta());
				//Sacar galleta
			} else if (opcion == 4){
				perro.interactuar(persona);
				//Interactuar
			} else if (opcion == 5){
				System.out.println("bye :) ");
				//Salir
			}
		}
	}
}