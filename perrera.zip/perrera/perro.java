import java.util.Random;
import java.util.Scanner;
public class perro{
    private Random rand = new Random();
    String interactuar;
    int animo_umbral;
    String morder;
    String ladrar;
    String mover_cola;
    int psican;



    public perro(){
        animo_umbral = (int) (rand.nextFloat() * 20-20);
        psican = (int) (rand.nextFloat() * 10-5);
        
    private void ladrar(){
        System.out.println("El perro esta momlesto o tiene hambre");
        interactuar = "ladrar";
    }

    private void morder(){
        System.out.println("El perro esta asustado, te ha mordido");
        interactuar = "morder";
    }

    private void mover_cola(){
    System.out.println("El perro esta comodo contigo y te quiere mucho");
    interactuar = "muestra confianza";
    }

    public int getAnimo(){
        return psican;
    }

    public int getUmbral(){
        return animo_umbral;
    }
    public String interactuar(){
        return interactuar;
    }
    public int psican(){
        return psican;
    }
    public String getAccion(){
        return interactuar;
    }


    private void psican(persona p){
        this.psican = (int)((1.0/p.getConfiabilidad())*(rand.nextFloat()-0.5)*10+this.psican);
        if(p.galleta()){
            p.darGalleta();
            this.psican += (1.0/p.getConfiabilidad()) * (rand.nextInt(2));
        }
        System.out.println("Mi nuevo estado de animo es: " + psican);
    }
    public void interactuar(persona p){
        psican(p);
        if(psican < animo_umbral){
            morder();
        } else if (psican < 0 && psican > animo_umbral){
            ladrar();
        } else if (psican > 0){
            mover_cola();
        }
    }

}
