import java.util.Random;
public class persona {
    public Random r= new Random();
    public int confiabilidad;
    public int sacar_galleta;
    public boolean no_galleta;
    public boolean dar_galleta;
    public boolean galleta;

    public persona()
    {
        confiabilidad= r.nextInt(11);
        sacar_galleta=r.nextInt(20);
        no_galleta=false;
        dar_galleta=true;
        galleta=true;
    }

    public int getConfiabilidad(){
        return confiabilidad;
    }

    public int tienedaGalleta(){
        return sacar_galleta;
    }

    public boolean darGalleta(){
        no_galleta = false;
        return no_galleta;
    }

    public void comportamiento(perro perro){
        if (perro.getAccion() == "Mordedura"){
            System.out.println("el peero esta de mal humor");
        } else if (perro.getAccion() == "ladrar"){
            System.out.println("el perro necesita algo");
        } else if (perro.getAccion() == "mover cola")
        System.out.println("el perro esta feliz cerca tuyo");
    }

    public boolean galleta(){
        return false;
    }

    public void interactuar(persona persona) {
    }

}
